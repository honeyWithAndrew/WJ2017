/*var asks = document.querySelectorAll('.faq .pair .ask');

for(var i = 0; i < asks.length; i++){
	asks[i].onclick = function(){
		var ans = this.parentNode.children[1];
		
		if(ans.style.display == 'block'){
			ans.style.display = 'none';
		}
		else{
			ans.style.display = 'block';
		}
	}
}*/

$('.faq .pair .ask').click(function(){
	$(this).next().slideToggle();
});