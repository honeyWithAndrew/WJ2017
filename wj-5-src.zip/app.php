<style>
	html{
		font-family: Arial;
	}
</style>
<?php
	$str = $_POST['name'] . ' - ' . $_POST['email'];
	file_put_contents('app.txt', "$str\n", FILE_APPEND);
	echo 'всё ок!';