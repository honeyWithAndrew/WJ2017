<!doctype html>
<html lang="ru">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width">
        <title>Мой сайт</title>
        <link href="css/styles.css" rel="stylesheet">
    </head>
    <body>
        <div class="navigation">
            <div class="wrapper">
                <img src="logo.png" alt="">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Team</a></li>
                    <li><a href="#">Portfolio</a></li>
                    <li><a href="#">Other</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
        </div>
        <div class="header">
            <div class="wrapper">
                <h1>Welcome to Motion</h1>
                <div class="subtitle">Asmart & Creative Single Page Template</div>
            </div>
        </div>
        <div class="advantages">
            <div class="wrapper">
                <h2>Smart & Creative</h2>
                <div class="subtitle">This is why you will use it</div>
                <div class="items">
                    <div class="item">
                        <img src="img/a1.png" alt="">
                        <div class="name">Multi purpose</div>
                        <div class="description">Lorem Impsum Lorem Impsum Lorem Impsum Lorem Impsum</div>
                    </div>
                    <div class="item">
                        <img src="img/a2.png" alt="">
                        <div class="name">Multi purpose</div>
                        <div class="description">Lorem Impsum Lorem Impsum Lorem Impsum Lorem Impsum</div>
                    </div>
                    <div class="item">
                        <img src="img/a3.png" alt="">
                        <div class="name">Multi purpose</div>
                        <div class="description">Lorem Impsum Lorem Impsum Lorem Impsum Lorem Impsum</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="experts">
            <div class="wrapper">
                <h2>Talented & Experts</h2>
                <div class="subtitle">This is our team :)</div>
				<div class="faq">
					<div class="pair">
						<div class="ask">1. Вопрос</div>
						<div class="answer">
							<p>Какой-то текстище. Какой-то текстище. Какой-то текстище.Какой-то текстище. Какой-то текстище.</p>
							<p>Какой-то текстище. Какой-то текстище. Какой-то текстище.Какой-то текстище. Какой-то текстище.</p>
							<p>Какой-то текстище. Какой-то текстище. Какой-то текстище.Какой-то текстище. Какой-то текстище.</p>
							<p>Какой-то текстище. Какой-то текстище. Какой-то текстище.Какой-то текстище. Какой-то текстище.</p>
						</div>
					</div>
					<div class="pair">
						<div class="ask">2. Вопрос</div>
						<div class="answer">
							<p>Какой-то текстище. Какой-то текстище. Какой-то текстище.Какой-то текстище. Какой-то текстище.</p>
							<p>Какой-то текстище. Какой-то текстище. Какой-то текстище.Какой-то текстище. Какой-то текстище.</p>
							<p>Какой-то текстище. Какой-то текстище. Какой-то текстище.Какой-то текстище. Какой-то текстище.</p>
							<p>Какой-то текстище. Какой-то текстище. Какой-то текстище.Какой-то текстище. Какой-то текстище.</p>
						</div>
					</div>
					<div class="pair">
						<div class="ask">3. Вопрос</div>
						<div class="answer">
							<p>Какой-то текстище. Какой-то текстище. Какой-то текстище.Какой-то текстище. Какой-то текстище.</p>
							<p>Какой-то текстище. Какой-то текстище. Какой-то текстище.Какой-то текстище. Какой-то текстище.</p>
							<p>Какой-то текстище. Какой-то текстище. Какой-то текстище.Какой-то текстище. Какой-то текстище.</p>
							<p>Какой-то текстище. Какой-то текстище. Какой-то текстище.Какой-то текстище. Какой-то текстище.</p>
						</div>
					</div>
				</div>
				<h2>Не нашли ответ? - Пишите!</h2>
				<form class="formAsk" method="post" action="app.php">
					<div>
						<span>Имя</span>
						<input type="text" name="name">
					</div>
					<div>
						<span>Email</span>
						<input type="text" name="email">
					</div>
					<div>
						<span>Вопрос</span>
						<textarea name="answer"></textarea>
					</div>
					<input type="submit" value="Отправить">
				</form>
            </div>
        </div>
        <div class="footer">
            <div class="wrapper">
                &copy; Не тырить!
            </div>
        </div>
		<script src="js/jquery-3.2.1.min.js"></script>
		<script src="js/script.js"></script>
    </body>
</html>







